## Usage

[Helm](https://helm.sh) must be installed to use the charts.  Please refer to
Helm's [documentation](https://helm.sh/docs) to get started.

### Add this repo
Once Helm has been set up correctly, add the repo as follows:

```shell
helm repo add phan https://phan2410.github.io/charts
```

If you had already added this repo earlier, run `helm repo update` to retrieve
the latest versions of the packages.  You can then run `helm search repo phan` to see the charts.

### Install the chart

To install `falcon-asgi-server` chart:

```shell
helm install falcon-asgi-server phan/falcon-asgi-server
```

or

```shell
helm install falcon-asgi-server oci://ghcr.io/phan2410/charts/falcon-asgi-server
```

To uninstall the chart:

```shell
helm delete falcon-asgi-server
```