{{/*
Expand the name of the chart.
*/}}
{{- define "dummy-service.name" -}}
{{- default .Chart.Name .Values.nameOverride . | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Replace for .Chart.Name to enable override in child charts
*/}}
{{- define "chart.name" -}}
{{- include "dummy-service.name" . }}
{{- end }}

{{/*
Replace for .Chart.Version to enable override in child charts
*/}}
{{- define "chart.version" -}}
{{- default .Chart.Version .Values.versionOverride . }}
{{- end }}

{{/*
Replace for .Chart.AppVersion to enable override in child charts
*/}}
{{- define "chart.app_version" -}}
{{- default .Chart.AppVersion .Values.appVersionOverride . }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "dummy-service.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := include "chart.name" . }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "dummy-service.chart" -}}
{{- printf "%s-%s" (include "chart.name" .) (include "chart.version" .) | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "dummy-service.labels" -}}
helm.sh/chart: {{ include "dummy-service.chart" . }}
{{ include "dummy-service.selectorLabels" . }}
{{- if (include "chart.app_version" .) }}
app.kubernetes.io/version: {{ include "chart.app_version" . | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "dummy-service.selectorLabels" -}}
app.kubernetes.io/name: {{ include "dummy-service.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "dummy-service.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "dummy-service.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Create the name of the istio gateway to use
*/}}
{{- define "dummy-service.istioGatewayName" -}}
{{- default (include "dummy-service.fullname" .) .Values.istio_gateway.name }}
{{- end }}
